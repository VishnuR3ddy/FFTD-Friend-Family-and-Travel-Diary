package com.ase.dto;

import lombok.Data;

@Data
public class Radio {
    private String status;
}
