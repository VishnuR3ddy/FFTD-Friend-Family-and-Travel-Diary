package com.ase;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MyFriendsDto {

    String email;
    String name;
}
